/* Spotify Design Article - Interaction Logic */

function updateClocks() {
    const clockElements = [
        { id: 'clock-1', offset: 1 }, // Stockholm / SEGBGSTO (CET)
        { id: 'clock-2', offset: 0 }, // London / UKLDN (GMT)
        { id: 'clock-3', offset: -5 } // New York / USNYBOS (EST)
    ];

    const now = new Date();
    const utcHours = now.getUTCHours();
    const utcMinutes = now.getUTCMinutes();
    const utcSeconds = now.getUTCSeconds();

    clockElements.forEach(clock => {
        let h = (utcHours + clock.offset + 24) % 24;
        let m = utcMinutes;
        let s = utcSeconds;

        h = h < 10 ? '0' + h : h;
        m = m < 10 ? '0' + m : m;
        s = s < 10 ? '0' + s : s;

        const el = document.getElementById(clock.id);
        if (el) {
            el.textContent = `${h}:${m}:${s}`;
        }
    });
}

// Update clocks every second
setInterval(updateClocks, 1000);
updateClocks();

// Share Button Interaction
const shareBtn = document.querySelector('.share-group .share-btn:last-child');
const copiedBtn = document.querySelector('.share-group .share-btn:first-child');

if (shareBtn && copiedBtn) {
    copiedBtn.style.display = 'none';

    shareBtn.addEventListener('click', () => {
        // Copy current URL (simulated)
        const dummy = document.createElement('input');
        document.body.appendChild(dummy);
        dummy.value = window.location.href;
        dummy.select();
        document.execCommand('copy');
        document.body.removeChild(dummy);

        // Visual feedback
        shareBtn.style.display = 'none';
        copiedBtn.style.display = 'block';

        setTimeout(() => {
            copiedBtn.style.display = 'none';
            shareBtn.style.display = 'block';
        }, 2000);
    });
}

// Scroll Progress Header (Phase 4 Polish)
window.addEventListener('scroll', () => {
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;

    // We could add a progress bar to the header here
    const header = document.querySelector('.header-nav');
    if (winScroll > 100) {
        header.style.boxShadow = 'var(--skin-shadow)';
    } else {
        header.style.boxShadow = 'none';
    }
});
