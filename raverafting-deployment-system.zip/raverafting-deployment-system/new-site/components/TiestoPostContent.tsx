import React from 'react';

/**
 * TiestoPostContent - High-Fidelity Article Block
 * Mirrors the green header, black nav, and sidebar widgets from the screenshot.
 */
const TiestoPostContent: React.FC = () => {
    return (
        <div className="raverafting-engine" style={{ background: '#f5f5f5', minHeight: '100vh', fontFamily: 'Lato, sans-serif' }}>
            {/* Top Bar */}
            <div className="top-bar" style={{ background: '#000', color: '#fff', padding: '10px 0', fontSize: '0.8rem' }}>
                <div className="container" style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div className="must-read">
                        <span style={{ background: '#000', fontWeight: 'bold', paddingRight: '10px' }}>MUST READ</span>
                        <span style={{ color: '#ccc' }}>Donald Trump health mystery deepens because the fresh bruises</span>
                    </div>
                    <div className="search-top">
                        <span style={{ color: '#888' }}>Search...</span>
                        <i className="fa fa-search" style={{ marginLeft: '10px' }}></i>
                    </div>
                </div>
            </div>

            {/* Green Header Area */}
            <header className="main-header" style={{ background: '#82c341', padding: '40px 0', textAlign: 'center' }}>
                <h1 style={{ margin: 0 }}>
                    <img
                        src="https://raverrafting.com/wp-content/uploads/raverrafting-logo-retina.png"
                        alt="raver rafting"
                        style={{ maxWidth: '300px' }}
                    />
                </h1>
            </header>

            {/* Navigation Bar */}
            <nav className="main-nav" style={{ background: '#000', borderBottom: '1px solid #333' }}>
                <div className="container" style={{ maxWidth: '1200px', margin: '0 auto' }}>
                    <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', justifyContent: 'center' }}>
                        {['News', 'Music', 'Giveaways', 'Store', 'Contact'].map((item) => (
                            <li key={item} style={{ position: 'relative' }}>
                                <a href="#" style={{ display: 'block', padding: '15px 20px', color: '#fff', textDecoration: 'none', textTransform: 'uppercase', fontSize: '0.85rem', fontWeight: 'bold' }}>
                                    {item} {['News', 'Music', 'Contact'].includes(item) && <i className="fa fa-caret-down" style={{ fontSize: '0.7rem', marginLeft: '5px' }}></i>}
                                </a>
                            </li>
                        ))}
                    </ul>
                </div>
            </nav>

            {/* Main Content & Sidebar Wrapper */}
            <div className="container" style={{ maxWidth: '1200px', margin: '30px auto', background: '#fff', boxShadow: '0 0 10px rgba(0,0,0,0.05)', display: 'flex' }}>

                {/* Article Content */}
                <main className="content-area" style={{ flex: '2', padding: '40px' }}>
                    <article>
                        <h1 style={{ fontFamily: 'Roboto Condensed, sans-serif', fontSize: '2.5rem', margin: '0 0 10px 0' }}>
                            Tiësto, Hedex, and BassLayerz Unite for ‘Click Click Click’
                        </h1>
                        <div className="meta" style={{ color: '#888', fontSize: '0.85rem', marginBottom: '30px', borderBottom: '1px solid #eee', paddingBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
                            <div>June 8, 2024 By <span style={{ color: '#7c13af', fontWeight: 'bold' }}>Lia Tabackman</span></div>
                            <div><i className="fa fa-comments-o"></i> 0</div>
                        </div>

                        <div className="facebook-share" style={{ background: '#3b5998', color: '#fff', padding: '10px 20px', width: '200px', borderRadius: '3px', marginBottom: '30px', display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                            <i className="fa fa-facebook" style={{ marginRight: '15px' }}></i>
                            <span style={{ fontWeight: 'bold' }}>Facebook</span>
                        </div>

                        <img
                            src="https://raverrafting.com/wp-content/uploads/Tiesto-x-Hedex-x-Basslayerz-jpg-1.jpg"
                            alt="Tiesto"
                            style={{ width: '100%', marginBottom: '20px' }}
                        />

                        <div className="post-body" style={{ color: '#444', lineHeight: '1.8' }}>
                            <p>iësto, Hedex, and Basslayerz have joined forces to create an epic D’n’B track, “Click Click Click,” and it’s nothing short of amazing. These artists are at the top of their game, and their accolades speak volumes.</p>
                            <p>Tiësto, a GRAMMY Award-winning legend, has over 8 billion global streams and has been crowned “#1 DJ” by Rolling Stone. Hedex, taking the D’n’B scene by storm, has toured across Australia, New Zealand, and the US...</p>
                        </div>
                    </article>
                </main>

                {/* Sidebar */}
                <aside className="sidebar" style={{ flex: '1', padding: '40px', background: '#fafafa', borderLeft: '1px solid #eee' }}>
                    {/* Search Widget */}
                    <div className="widget" style={{ marginBottom: '40px' }}>
                        <h3 style={{ background: '#000', color: '#fff', padding: '10px', fontSize: '1rem', textTransform: 'uppercase', margin: '0 0 15px 0' }}>Can’t Find What You’re Looking For?</h3>
                        <div style={{ display: 'flex' }}>
                            <input type="text" style={{ flex: 1, padding: '10px', border: '1px solid #ddd' }} />
                            <button style={{ background: '#82c341', border: 'none', color: '#fff', padding: '0 20px', fontWeight: 'bold', cursor: 'pointer' }}>Search</button>
                        </div>
                    </div>

                    {/* Spotify Widget */}
                    <div className="widget" style={{ marginBottom: '40px' }}>
                        <img
                            src="https://whiteraverraft.wpenginepowered.com/wp-content/uploads/RR_Spotify.jpg"
                            alt="Spotify Playlist"
                            style={{ width: '100%' }}
                        />
                    </div>

                    {/* Recent Posts */}
                    <div className="widget">
                        <h3 style={{ background: '#000', color: '#fff', padding: '10px', fontSize: '1rem', textTransform: 'uppercase', margin: '0 0 15px 0' }}>Recent Posts</h3>
                        <ul style={{ listStyle: 'none', padding: 0 }}>
                            {['Wazamba casino Wazamba.12700', 'Tower Rush: The Ultimate Manual...', 'Tower Rush Galaxsys : Avis...'].map((post, idx) => (
                                <li key={idx} style={{ marginBottom: '20px' }}>
                                    <h4 style={{ margin: '0 0 5px 0', fontSize: '0.95rem' }}>
                                        <a href="#" style={{ color: '#7c13af', textDecoration: 'none', fontWeight: 'bold' }}>{post}</a>
                                    </h4>
                                    <div style={{ color: '#999', fontSize: '0.75rem' }}>February 3, 2026 <span style={{ marginLeft: '10px' }}><i className="fa fa-comments-o"></i> 0</span></div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </aside>

            </div>
        </div>
    );
};

export default TiestoPostContent;
