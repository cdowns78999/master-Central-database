import React from 'react';

/**
 * BlogContent - Canonical Blog Feed block
 * Mirrors the WordPress 'Category 2 Columns' template with a posts slider placeholder.
 */
const BlogContent: React.FC = () => {
    return (
        <section className="blog-content tactical-node p-4 md:p-8 space-y-12">
            {/* Header Slider Placeholder */}
            <div className="blog-slider bg-white/5 border-2 border-dashed border-[#00ffcc]/30 h-64 md:h-96 rounded-lg flex items-center justify-center text-center p-8">
                <div>
                    <div className="text-[#00ffcc] text-xs uppercase tracking-[4px] mb-2 font-bold">1 Block Posts Slider</div>
                    <h2 className="text-2xl md:text-4xl font-bold uppercase tracking-widest text-white">Featured Intel Uplink</h2>
                    <div className="mt-4 text-[#ff00ff] font-mono text-sm">[ CYCLE_LATEST_INTEL ]</div>
                </div>
            </div>

            {/* Post Grid (2 Columns) */}
            <div className="posts-grid grid grid-cols-1 lg:grid-cols-2 gap-8">
                {[1, 2, 3, 4].map((i) => (
                    <article key={i} className="post-card bg-white/5 border border-white/10 rounded-lg overflow-hidden flex flex-col hover:border-[#00ffcc]/50 transition-colors">
                        <div className="aspect-video bg-white/10 w-full animate-pulse"></div>
                        <div className="p-6 space-y-4">
                            <div className="flex justify-between items-center text-[10px] uppercase tracking-widest font-bold">
                                <span className="text-[#00ffcc]">Latest Posts</span>
                                <span className="text-white/40">May 4, 2013</span>
                            </div>
                            <h3 className="text-xl font-bold text-white uppercase tracking-wide">Tactical Deployment Report #{i}</h3>
                            <p className="text-white/60 text-sm line-clamp-3">
                                Extraction protocols initiated for the latest electronic music developments. Analysis of current scene trends and festival logistics ongoing.
                            </p>
                            <div className="pt-4">
                                <span className="text-xs text-[#ff00ff] font-bold uppercase tracking-widest cursor-not-allowed">[ READ_MORE ]</span>
                            </div>
                        </div>
                    </article>
                ))}
            </div>

            {/* Pagination Placeholder */}
            <div className="pagination flex justify-center gap-4 pt-12">
                <div className="w-10 h-10 border border-[#00ffcc] flex items-center justify-center text-[#00ffcc] font-bold">1</div>
                <div className="w-10 h-10 border border-white/10 flex items-center justify-center text-white/40">2</div>
                <div className="w-10 h-10 border border-white/10 flex items-center justify-center text-white/40">3</div>
            </div>
        </section>
    );
};

export default BlogContent;
