import React from 'react';

/**
 * DaylightVegasContent - High-fidelity venue block
 * Mirrors the canonical green/black layout established for RaveRafting.
 */
const DaylightVegasContent: React.FC = () => {
    return (
        <div className="daylight-vegas-content">
            <article className="venue-block bg-white p-10 shadow-sm">
                <header className="mb-8">
                    <h1 className="text-4xl font-bold font-condensed uppercase tracking-tighter border-b-4 border-primary-green inline-block pb-2 mb-4">
                        Daylight Beach Club
                    </h1>
                    <div className="flex items-center text-sm font-condensed font-bold text-purple-700 uppercase tracking-widest">
                        <span>Las Vegas, Nevada</span>
                        <span className="mx-2 text-gray-300">|</span>
                        <span>Tactical Oasis</span>
                    </div>
                </header>

                <div className="venue-media mb-8 border border-gray-100 bg-gray-50 aspect-video flex items-center justify-center relative overflow-hidden">
                    <div className="text-3xl font-condensed font-bold text-gray-200 uppercase">
                        Daylight Las Vegas Visual Asset
                    </div>
                </div>

                <div className="venue-copy text-lg leading-relaxed text-gray-700 space-y-6">
                    <p>
                        The ultimate strategic poolside experience. From high-noon sets to sunset showdowns, Daylight is the desert's premier tactical oasis.
                    </p>
                    <p>
                        Designed for high-impact electronic music events, Daylight features a sprawling pool deck, luxury cabanas, and a state-of-the-art stage that has hosted some of the biggest names in the industry.
                    </p>
                </div>
            </article>

            {/* In a real Next.js app, the Sidebar would be its own component or part of the layout, 
                but for parity with the mock site, we include the structural markers here. */}
            <aside className="mt-10 md:hidden">
                <div className="p-4 bg-gray-100 border-l-4 border-black">
                    <h4 className="font-condensed font-bold uppercase mb-2">Sector Intel</h4>
                    <p className="text-sm">Navigation restricted to Mobile HQ.</p>
                </div>
            </aside>

            <style jsx>{`
                .font-condensed {
                    font-family: 'Roboto Condensed', sans-serif;
                }
                .border-primary-green {
                    border-color: #82c341;
                }
                .text-primary-green {
                    color: #82c341;
                }
            `}</style>
        </div>
    );
};

export default DaylightVegasContent;
