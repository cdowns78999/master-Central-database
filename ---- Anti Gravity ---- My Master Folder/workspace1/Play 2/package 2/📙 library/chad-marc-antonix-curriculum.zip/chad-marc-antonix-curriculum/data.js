/* ══════════════════════════════════════════════════════════════
   MARC ANTONIX — CURRICULUM DATA
   All [DATA_NEEDED] placeholders will be replaced with real content
   ══════════════════════════════════════════════════════════════ */

const curriculumData = {

    home: {
        artistName: "Marc Antonix",
        heroTitle: "Your 4-Star Curriculum",
        heroSub: "Each star below is a self-contained proposal — built from verified strategy, real pricing, and platform data. Tap any star to walk through the full plan step by step.",
        badge: "Ahead Artist Solutions"
    },

    stars: {

        /* ─────────────────────────────────────
           ⭐[1] Spotify Ads + Playlisting + Localization
           ───────────────────────────────────── */
        "star-1": {
            title: "Spotify Ads + Playlisting + Localization",
            color: "#1ed760",
            colorVar: "--star-1",
            file: "star1.html",
            icon: "🎯",
            tagline: "[DATA_NEEDED] — Brief pitch for this proposal",
            phases: [
                {
                    label: "Phase 1",
                    title: "Spotify Ad Studio Campaign Setup",
                    steps: [
                        {
                            heading: "Campaign Architecture",
                            body: "[DATA_NEEDED] — Describe the campaign structure, targeting, budget allocation",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Audience Targeting Strategy",
                            body: "[DATA_NEEDED] — Define target demographics, geo, genre fans",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Creative & Ad Format",
                            body: "[DATA_NEEDED] — Audio ad specs, companion image, CTA strategy",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 2",
                    title: "Playlist Placement Strategy",
                    steps: [
                        {
                            heading: "Editorial & Algorithmic Targeting",
                            body: "[DATA_NEEDED] — Which playlists, submission strategy, timing",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Independent Curator Outreach",
                            body: "[DATA_NEEDED] — Curator list, pitch template, follow-up plan",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 3",
                    title: "Localization & International Push",
                    steps: [
                        {
                            heading: "Market Selection",
                            body: "[DATA_NEEDED] — Target countries, language considerations, local playlists",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Localized Ad Creatives",
                            body: "[DATA_NEEDED] — Translated assets, regional CTA, cultural hooks",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                }
            ],
            benchmarks: [
                { value: "[DATA_NEEDED]", label: "Expected Reach", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Cost Per Stream", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Playlist Adds Target", source: "[SOURCE TEXT]" }
            ]
        },

        /* ─────────────────────────────────────
           ⭐[2] EPK + Website + Discount Pricing
           ───────────────────────────────────── */
        "star-2": {
            title: "EPK + Website + Discount Pricing",
            color: "#3b82f6",
            colorVar: "--star-2",
            file: "star2.html",
            icon: "🌐",
            tagline: "[DATA_NEEDED] — Brief pitch for this proposal",
            phases: [
                {
                    label: "Phase 1",
                    title: "Electronic Press Kit Build",
                    steps: [
                        {
                            heading: "EPK Structure & Content",
                            body: "[DATA_NEEDED] — Bio, photos, press quotes, streaming links, contact",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Visual Design & Branding",
                            body: "[DATA_NEEDED] — Color palette, typography, image treatment, layout",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 2",
                    title: "Artist Website Development",
                    steps: [
                        {
                            heading: "Site Architecture",
                            body: "[DATA_NEEDED] — Pages, navigation, mobile-first approach, hosting",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Content & Integration",
                            body: "[DATA_NEEDED] — Spotify embeds, social links, mailing list, merch",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 3",
                    title: "Discount Pricing Breakdown",
                    steps: [
                        {
                            heading: "Bundle Pricing",
                            body: "[DATA_NEEDED] — What's included, savings vs individual, payment terms",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                }
            ],
            benchmarks: [
                { value: "[DATA_NEEDED]", label: "EPK Delivery", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Website Launch", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Bundle Savings", source: "[SOURCE TEXT]" }
            ]
        },

        /* ─────────────────────────────────────
           ⭐[3] LOUIEJAYXX - Escape EP
           ───────────────────────────────────── */
        "star-3": {
            title: "LOUIEJAYXX — Escape EP",
            color: "#a855f7",
            colorVar: "--star-3",
            file: "star3.html",
            icon: "💿",
            tagline: "[DATA_NEEDED] — Brief pitch for this proposal",
            phases: [
                {
                    label: "Phase 1",
                    title: "EP Rollout Strategy",
                    steps: [
                        {
                            heading: "Release Timeline",
                            body: "[DATA_NEEDED] — Single cadence, pre-save, release week plan",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Visual Identity for Escape EP",
                            body: "[DATA_NEEDED] — Cover art direction, visual teasers, content calendar",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 2",
                    title: "Marketing & Promotion",
                    steps: [
                        {
                            heading: "Platform Strategy",
                            body: "[DATA_NEEDED] — Spotify, Apple Music, TikTok, IG Reels, YouTube",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Paid Promotion Plan",
                            body: "[DATA_NEEDED] — Ad spend allocation, platform breakdown, KPIs",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 3",
                    title: "Post-Release & Sustain",
                    steps: [
                        {
                            heading: "Algorithmic Momentum",
                            body: "[DATA_NEEDED] — Discovery Mode, Release Radar, playlist push timing",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Fan Engagement Cycle",
                            body: "[DATA_NEEDED] — Behind-the-scenes, fan UGC, engagement loops",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                }
            ],
            benchmarks: [
                { value: "[DATA_NEEDED]", label: "First Month Streams", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Playlist Adds", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Save Rate Target", source: "[SOURCE TEXT]" }
            ]
        },

        /* ─────────────────────────────────────
           ⭐[4] Spotify 'Viral' Algorithm
           ───────────────────────────────────── */
        "star-4": {
            title: "Spotify 'Viral' Algorithm",
            color: "#f59e0b",
            colorVar: "--star-4",
            file: "star4.html",
            icon: "⚡",
            tagline: "[DATA_NEEDED] — Brief pitch for this proposal",
            phases: [
                {
                    label: "Phase 1",
                    title: "Algorithm Mechanics Breakdown",
                    steps: [
                        {
                            heading: "How Spotify's Algorithm Works",
                            body: "[DATA_NEEDED] — Release Radar, Discover Weekly, Radio, autoplay triggers",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Key Signals That Trigger Virality",
                            body: "[DATA_NEEDED] — Save rate, skip rate, completion rate, repeat listens",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 2",
                    title: "Strategic Activation Plan",
                    steps: [
                        {
                            heading: "Pre-Release Optimization",
                            body: "[DATA_NEEDED] — Canvas, pre-save funnel, social seeding, pitch timing",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Release Week Execution",
                            body: "[DATA_NEEDED] — First 24hr push, save CTA blitz, story sequence",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        },
                        {
                            heading: "Post-Release Sustain Loop",
                            body: "[DATA_NEEDED] — Marquee/Showcase timing, playlist re-pitch, ad retarget",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                },
                {
                    label: "Phase 3",
                    title: "Measurement & Iteration",
                    steps: [
                        {
                            heading: "KPI Dashboard Setup",
                            body: "[DATA_NEEDED] — Metrics to track, benchmarks, reporting cadence",
                            embed: "[EMBED SLOT]",
                            link: "[LINK SLOT]",
                            sourceText: "[SOURCE TEXT]"
                        }
                    ]
                }
            ],
            benchmarks: [
                { value: "[DATA_NEEDED]", label: "Algorithmic Reach", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Save Rate Benchmark", source: "[SOURCE TEXT]" },
                { value: "[DATA_NEEDED]", label: "Viral Threshold", source: "[SOURCE TEXT]" }
            ]
        }
    }
};
