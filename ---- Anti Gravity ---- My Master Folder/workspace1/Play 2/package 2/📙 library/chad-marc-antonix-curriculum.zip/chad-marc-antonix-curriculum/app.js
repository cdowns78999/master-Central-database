/* ══════════════════════════════════════════════════════════════
   MARC ANTONIX — APP LOGIC
   Nav routing, curriculum rendering, overlay, fade transitions
   ══════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
    const contentRoot = document.getElementById('content-root');
    const navItems = document.querySelectorAll('.nav-item[data-view]');
    const pageCategory = document.body.getAttribute('data-page-category') || 'Home';

    // ── Set active nav state based on current page ──
    navItems.forEach(item => {
        if (item.getAttribute('data-view') === pageCategory) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // ── Route to correct render ──
    if (pageCategory === 'Home') {
        renderHome();
    } else {
        const starKey = 'star-' + pageCategory.replace('Star ', '');
        renderCurriculum(starKey);
    }

    // ══════════════════════════════════════
    // RENDER: Home — 4 Star Preview Cards
    // ══════════════════════════════════════
    function renderHome() {
        if (!contentRoot || typeof curriculumData === 'undefined') return;

        const stars = curriculumData.stars;
        let html = '';

        html += '<div class="section-header"><div class="section-dot"></div><span class="section-title">Your Proposals</span></div>';
        html += '<div class="star-cards-grid">';

        let starIndex = 0;
        for (const key in stars) {
            const star = stars[key];
            starIndex++;
            const phaseCount = star.phases.length;
            const stepCount = star.phases.reduce((sum, p) => sum + p.steps.length, 0);

            html += `
                <a href="${star.file}" class="star-card" data-star="${starIndex}" style="text-decoration:none;">
                    <span class="star-num">${starIndex}</span>
                    <div class="star-icon">${star.icon}</div>
                    <h3>${star.title}</h3>
                    <p>${star.tagline}</p>
                    <div style="margin-top:16px;display:flex;gap:16px;">
                        <span style="font-size:0.55rem;text-transform:uppercase;letter-spacing:1.5px;font-weight:800;color:var(--text-ghost);">${phaseCount} Phases</span>
                        <span style="font-size:0.55rem;text-transform:uppercase;letter-spacing:1.5px;font-weight:800;color:var(--text-ghost);">${stepCount} Steps</span>
                    </div>
                    <span class="star-tag">Star ${starIndex}</span>
                </a>
            `;
        }

        html += '</div>';

        // Fade in
        contentRoot.classList.add('fade-out');
        setTimeout(() => {
            contentRoot.innerHTML = html;
            contentRoot.classList.remove('fade-out');
        }, 150);
    }

    // ══════════════════════════════════════
    // RENDER: Curriculum — Phase Cards + Benchmarks
    // ══════════════════════════════════════
    function renderCurriculum(starKey) {
        if (!contentRoot || typeof curriculumData === 'undefined') return;

        const star = curriculumData.stars[starKey];
        if (!star) return;

        let html = '';
        const accentColor = star.color;

        // ── Phase Cards ──
        star.phases.forEach((phase, pi) => {
            html += `
                <div class="section-header">
                    <div class="section-dot" style="background:${accentColor};"></div>
                    <span class="section-title">${phase.title}</span>
                </div>
                <div class="phase-card">
                    <span class="phase-label" style="background:${accentColor}15;color:${accentColor};">${phase.label}</span>
                    <h3>${phase.title}</h3>
            `;

            phase.steps.forEach((step, si) => {
                const isPlaceholder = step.body.includes('[DATA_NEEDED]');
                html += `
                    <div class="step-item">
                        <div class="step-heading">${step.heading}</div>
                        <div class="step-body ${isPlaceholder ? 'placeholder-text' : ''}">${step.body}</div>
                `;

                // Embed slot
                if (step.embed && step.embed.includes('[EMBED SLOT]')) {
                    html += `<div class="embed-slot placeholder"><span class="placeholder-text">[EMBED SLOT] — Paste embed code here</span></div>`;
                }

                // Link slot
                if (step.link && step.link.includes('[LINK SLOT]')) {
                    html += `<div class="link-slot placeholder"><span class="placeholder-text">[LINK SLOT] — Add URL</span></div>`;
                }

                // Source text slot
                if (step.sourceText && step.sourceText.includes('[SOURCE TEXT]')) {
                    html += `<div class="source-slot placeholder"><span class="placeholder-text">[SOURCE TEXT] — Add verified source</span></div>`;
                }

                html += `</div>`;
            });

            html += `</div>`;
        });

        // ── Benchmark Grid ──
        if (star.benchmarks && star.benchmarks.length > 0) {
            html += `
                <div class="section-header">
                    <div class="section-dot" style="background:${accentColor};"></div>
                    <span class="section-title">Key Benchmarks</span>
                </div>
                <div class="benchmark-grid">
            `;

            star.benchmarks.forEach(bench => {
                const isPlaceholder = bench.value.includes('[DATA_NEEDED]');
                html += `
                    <div class="bench-card ${isPlaceholder ? 'placeholder' : ''}">
                        <div class="bench-value" style="color:${isPlaceholder ? 'rgba(59,130,246,0.5)' : accentColor};">${bench.value}</div>
                        <div class="bench-label">${bench.label}</div>
                        <div class="bench-source ${isPlaceholder ? 'placeholder-text' : ''}">${bench.source}</div>
                    </div>
                `;
            });

            html += '</div>';
        }

        // Fade in
        contentRoot.classList.add('fade-out');
        setTimeout(() => {
            contentRoot.innerHTML = html;
            contentRoot.classList.remove('fade-out');
        }, 150);
    }
});

// ══════════════════════════════════════
// DATA OVERLAY
// ══════════════════════════════════════
function toggleOverlay() {
    const overlay = document.getElementById('dataOverlay');
    if (overlay) {
        overlay.classList.toggle('active');
    }
}

// Close overlay on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const overlay = document.getElementById('dataOverlay');
        if (overlay && overlay.classList.contains('active')) {
            overlay.classList.remove('active');
        }
    }
});

// Close overlay on backdrop click
document.addEventListener('click', (e) => {
    const overlay = document.getElementById('dataOverlay');
    if (e.target === overlay) {
        overlay.classList.remove('active');
    }
});
