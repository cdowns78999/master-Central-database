chrome.runtime.onInstalled.addListener(() => {
    console.log('Master Elite Extension Installed');
});

// Listener for messages from popup or content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'PING') {
        sendResponse({ status: 'ALIVE' });
    }
});
